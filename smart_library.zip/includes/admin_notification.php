<?php

if (
    $_SESSION['role'] == 'admin'
    ||
    $_SESSION['role'] == 'super_admin'
) {

    $user_id = $_SESSION['user_id'];

    // ==========================
    // TOTAL NOTIF ADMIN
    // ==========================
    $notifTotalQuery = mysqli_query($koneksi, "
        SELECT id
        FROM notifikasi
        WHERE user_id = '$user_id'
        AND dibaca = 0
    ");

    $totalNotif = 0;

    if ($notifTotalQuery) {

        $totalNotif = mysqli_num_rows($notifTotalQuery);

    }

    // ==========================
    // AMBIL DATA NOTIF ADMIN
    // ==========================
    $notifQuery = mysqli_query($koneksi, "
        SELECT *
        FROM notifikasi
        WHERE user_id = '$user_id'
        ORDER BY created_at DESC
        LIMIT 15
    ");

}

?>