-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2026 at 05:43 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_library`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `penulis` varchar(100) NOT NULL,
  `kategori_id` int(11) DEFAULT NULL,
  `stok` int(11) DEFAULT 0,
  `tahun_terbit` int(11) DEFAULT NULL,
  `cover` varchar(255) DEFAULT 'https://placehold.co/100x150',
  `deskripsi` text DEFAULT NULL,
  `tipe` enum('fisik','ebook') DEFAULT NULL,
  `kode_buku` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id`, `judul`, `penulis`, `kategori_id`, `stok`, `tahun_terbit`, `cover`, `deskripsi`, `tipe`, `kode_buku`) VALUES
(1, 'Pemrograman Web Modern', 'Budi Santoso', 1, 6, 2023, 'pemweb.jpg', NULL, 'fisik', 'BK001'),
(2, 'Desain Grafis Dasar', 'Ani Wijaya', 2, 3, 2022, 'desain.jpg', NULL, 'fisik', 'BK002'),
(3, 'Fisika Kelas 12', 'Prof. Andi', 3, 11, 2021, 'fisika_kelas_12.png', NULL, 'ebook', 'BK003'),
(4, 'Bahasa Indonesia', 'Tim Guru', 3, 9, 2020, 'bahasa_indonesia.jpg', NULL, 'fisik', 'BK004'),
(5, 'Algoritma & Struktur Data', 'Dewi Sartika', 1, 4, 2024, 'algoritma_struktur_data.jpg', NULL, 'fisik', 'BK005'),
(6, 'Laskar Pelangi', 'Andrea Hirata', 4, 5, 2005, 'laskar_pelangi.jpg', NULL, 'fisik', NULL),
(7, 'Bumi', 'Tere Liye', 4, 4, 2014, 'bumi.jpg', NULL, 'fisik', NULL),
(8, 'Dilan 1990', 'Pidi Baiq', 4, 4, 2014, 'dilan_1990.jpg', NULL, 'fisik', NULL),
(9, 'Negeri 5 Menara', 'Ahmad Fuadi', 4, 5, 2009, 'negeri_5_menara.jpg', NULL, 'fisik', NULL),
(10, 'Matahari', 'Tere Liye', 4, 15, NULL, 'matahari.jpg', NULL, NULL, NULL),
(11, 'Basis Data', 'Penerbit Erlangga', 3, 25, NULL, '1777344055_basis_data_smk_kelas12.png', NULL, 'fisik', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `buku_item`
--

CREATE TABLE `buku_item` (
  `id` int(11) NOT NULL,
  `buku_id` int(11) NOT NULL,
  `kode_buku` varchar(50) NOT NULL,
  `status` enum('available','borrowed') DEFAULT 'available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku_item`
--

INSERT INTO `buku_item` (`id`, `buku_id`, `kode_buku`, `status`, `created_at`) VALUES
(1, 1, 'BK001-1', 'available', '2026-04-27 16:22:29'),
(2, 1, 'BK001-2', 'available', '2026-04-27 16:22:29'),
(3, 1, 'BK001-3', 'available', '2026-04-27 16:22:29'),
(4, 1, 'BK001-4', 'available', '2026-04-27 16:22:29'),
(5, 7, 'BK007-1', 'available', '2026-04-28 02:46:54'),
(6, 7, 'BK007-2', 'available', '2026-04-28 02:46:54'),
(7, 7, 'BK007-3', 'available', '2026-04-28 02:46:54'),
(8, 7, 'BK007-4', 'available', '2026-04-28 02:46:54'),
(9, 7, 'BK007-5', 'available', '2026-04-28 02:46:54'),
(10, 7, 'BK007-6', 'available', '2026-04-28 02:46:54'),
(11, 8, 'BK008-1', 'available', '2026-04-28 02:50:14'),
(12, 8, 'BK008-2', 'available', '2026-04-28 02:50:14'),
(13, 8, 'BK008-3', 'available', '2026-04-28 02:50:14'),
(14, 8, 'BK008-4', 'available', '2026-04-28 02:50:14'),
(15, 9, 'BK009-1', 'available', '2026-04-28 02:50:30'),
(16, 9, 'BK009-2', 'available', '2026-04-28 02:50:30'),
(17, 9, 'BK009-3', 'available', '2026-04-28 02:50:30'),
(18, 9, 'BK009-4', 'available', '2026-04-28 02:50:30'),
(19, 9, 'BK009-5', 'available', '2026-04-28 02:50:30'),
(20, 10, 'BK010-1', 'available', '2026-04-28 02:50:53'),
(21, 10, 'BK010-2', 'available', '2026-04-28 02:50:53'),
(22, 10, 'BK010-3', 'available', '2026-04-28 02:50:53'),
(23, 10, 'BK010-4', 'available', '2026-04-28 02:50:53'),
(24, 10, 'BK010-5', 'available', '2026-04-28 02:50:53'),
(25, 10, 'BK010-6', 'available', '2026-04-28 02:50:53'),
(26, 10, 'BK010-7', 'available', '2026-04-28 02:50:53'),
(27, 10, 'BK010-8', 'available', '2026-04-28 02:50:53'),
(28, 10, 'BK010-9', 'available', '2026-04-28 02:50:53'),
(29, 10, 'BK010-10', 'available', '2026-04-28 02:50:53'),
(30, 10, 'BK010-11', 'available', '2026-04-28 02:50:53'),
(31, 10, 'BK010-12', 'available', '2026-04-28 02:50:53'),
(32, 10, 'BK010-13', 'available', '2026-04-28 02:50:53'),
(33, 10, 'BK010-14', 'available', '2026-04-28 02:50:53'),
(34, 10, 'BK010-15', 'available', '2026-04-28 02:50:53'),
(35, 11, 'BK011-1', 'available', '2026-04-28 02:51:12'),
(36, 11, 'BK011-2', 'available', '2026-04-28 02:51:12'),
(37, 11, 'BK011-3', 'available', '2026-04-28 02:51:12'),
(38, 11, 'BK011-4', 'available', '2026-04-28 02:51:12'),
(39, 11, 'BK011-5', 'available', '2026-04-28 02:51:12'),
(40, 11, 'BK011-6', 'available', '2026-04-28 02:51:12'),
(41, 11, 'BK011-7', 'available', '2026-04-28 02:51:12'),
(42, 11, 'BK011-8', 'available', '2026-04-28 02:51:12'),
(43, 11, 'BK011-9', 'available', '2026-04-28 02:51:12'),
(44, 11, 'BK011-10', 'available', '2026-04-28 02:51:12'),
(45, 11, 'BK011-11', 'available', '2026-04-28 02:51:12'),
(46, 11, 'BK011-12', 'available', '2026-04-28 02:51:12'),
(47, 11, 'BK011-13', 'available', '2026-04-28 02:51:12'),
(48, 11, 'BK011-14', 'available', '2026-04-28 02:51:12'),
(49, 11, 'BK011-15', 'available', '2026-04-28 02:51:12'),
(50, 11, 'BK011-16', 'available', '2026-04-28 02:51:12'),
(51, 11, 'BK011-17', 'available', '2026-04-28 02:51:12'),
(52, 11, 'BK011-18', 'available', '2026-04-28 02:51:12'),
(53, 11, 'BK011-19', 'available', '2026-04-28 02:51:12'),
(54, 11, 'BK011-20', 'available', '2026-04-28 02:51:12'),
(55, 11, 'BK011-21', 'available', '2026-04-28 02:51:12'),
(56, 11, 'BK011-22', 'available', '2026-04-28 02:51:12'),
(57, 11, 'BK011-23', 'available', '2026-04-28 02:51:12'),
(58, 11, 'BK011-24', 'available', '2026-04-28 02:51:12'),
(59, 11, 'BK011-25', 'available', '2026-04-28 02:51:12'),
(60, 6, 'BK006-1', 'available', '2026-04-28 03:27:42'),
(61, 6, 'BK006-2', 'available', '2026-04-28 03:27:42'),
(62, 6, 'BK006-3', 'available', '2026-04-28 03:27:42');

-- --------------------------------------------------------

--
-- Table structure for table `ebook`
--

CREATE TABLE `ebook` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `penulis` varchar(100) NOT NULL,
  `harga` decimal(10,2) NOT NULL,
  `file_url` varchar(255) DEFAULT NULL,
  `cover` varchar(255) DEFAULT 'https://placehold.co/100x150'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ebook`
--

INSERT INTO `ebook` (`id`, `judul`, `penulis`, `harga`, `file_url`, `cover`) VALUES
(1, 'Panduan UAS Pemrograman', 'Tim IT', 25000.00, NULL, 'https://placehold.co/100x150'),
(2, 'Novel Laskar Pelangi', 'Andrea Hirata', 45000.00, NULL, 'https://placehold.co/100x150');

-- --------------------------------------------------------

--
-- Table structure for table `ebook_transactions`
--

CREATE TABLE `ebook_transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ebook_id` int(11) NOT NULL,
  `tanggal_beli` date NOT NULL,
  `total_harga` decimal(10,2) NOT NULL,
  `status_pembayaran` enum('lunas','pending') DEFAULT 'lunas'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ebook_transactions`
--

INSERT INTO `ebook_transactions` (`id`, `user_id`, `ebook_id`, `tanggal_beli`, `total_harga`, `status_pembayaran`) VALUES
(3, 2, 1, '2025-06-01', 25000.00, 'lunas'),
(4, 2, 2, '2025-06-05', 45000.00, 'lunas');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(50) NOT NULL,
  `jenis` enum('Fiction','Non-Fiction') DEFAULT 'Non-Fiction'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama_kategori`, `jenis`) VALUES
(1, 'Pemrograman', 'Non-Fiction'),
(2, 'Desain', 'Non-Fiction'),
(3, 'Mapel', 'Non-Fiction'),
(4, 'Novel', 'Fiction'),
(5, 'Sains', 'Non-Fiction');

-- --------------------------------------------------------

--
-- Table structure for table `notifikasi`
--

CREATE TABLE `notifikasi` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pesan` text NOT NULL,
  `tipe` enum('info','warning','error','success') DEFAULT 'info',
  `dibaca` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE `peminjaman` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `buku_id` int(11) NOT NULL,
  `tanggal_pinjam` date NOT NULL,
  `tanggal_jatuh_tempo` date NOT NULL,
  `tanggal_kembali` date DEFAULT NULL,
  `status` enum('dipinjam','dikembalikan','terlambat') DEFAULT 'dipinjam',
  `kode_buku` varchar(20) DEFAULT NULL,
  `denda` int(11) DEFAULT 0,
  `nis` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `peminjaman`
--

INSERT INTO `peminjaman` (`id`, `user_id`, `buku_id`, `tanggal_pinjam`, `tanggal_jatuh_tempo`, `tanggal_kembali`, `status`, `kode_buku`, `denda`, `nis`) VALUES
(1, 2, 1, '2026-04-23', '2026-04-30', '2026-04-23', 'dikembalikan', NULL, 0, NULL),
(2, 2, 1, '2026-04-27', '2026-05-04', '2026-04-27', 'dikembalikan', '', 0, NULL),
(3, 2, 1, '2026-04-27', '2026-05-04', NULL, 'dipinjam', 'BK001', 0, NULL),
(4, 2, 3, '2026-04-27', '2026-05-04', '2026-04-27', 'dikembalikan', 'BK003', 0, NULL),
(5, 2, 4, '2026-04-27', '2026-05-04', '2026-04-27', 'dikembalikan', 'BK004', 0, NULL),
(6, 2, 3, '2026-04-27', '2026-05-04', NULL, 'dipinjam', 'BK003', 0, NULL),
(7, 2, 2, '2026-04-27', '2026-05-04', NULL, '', 'BK002', 0, NULL),
(8, 2, 4, '2026-04-27', '2026-05-04', NULL, 'dipinjam', 'BK004', 0, NULL),
(9, 2, 3, '2026-04-27', '2026-05-04', NULL, 'dipinjam', 'BK003', 0, NULL),
(11, 2, 3, '2026-04-27', '2026-05-04', '2026-04-28', 'dikembalikan', 'BK003', 0, NULL),
(12, 2, 3, '2026-04-27', '2026-05-04', NULL, '', 'BK003', 0, NULL),
(13, 2, 3, '2026-04-27', '2026-05-04', '2026-04-27', 'dikembalikan', 'BK003', 0, NULL),
(14, 2, 1, '2026-04-27', '2026-05-04', '2026-04-27', 'dikembalikan', 'BK001', 0, NULL),
(15, 2, 1, '2026-04-27', '2026-05-04', NULL, '', 'BK001-1', 0, NULL),
(16, 2, 7, '2026-04-28', '2026-05-05', NULL, '', 'BK007-2', 0, ''),
(17, 2, 10, '2026-04-28', '2026-05-05', NULL, 'dipinjam', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_ebook`
--

CREATE TABLE `transaksi_ebook` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ebook_id` int(11) NOT NULL,
  `tanggal_beli` date NOT NULL,
  `status_pembayaran` enum('lunas','pending') DEFAULT 'lunas'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','siswa') DEFAULT 'siswa',
  `nis` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `password`, `role`, `nis`, `created_at`) VALUES
(1, 'Admin Perpus', 'admin@smkpgri1.sch.id', 'admin123', 'admin', NULL, '2026-04-23 00:31:19'),
(2, 'Siswa ', 'siswa@smkpgri1.sch.id', 'siswa123', 'siswa', '24050974035', '2026-04-23 00:31:19'),
(3, 'nelsya', 'nelsya@smkpgri1.sch.id', 'icha12345', 'siswa', '12345', '2026-04-23 01:37:48'),
(4, 'aurel', 'aurel@smkpgri1.sch.id', 'aurel12345', 'siswa', '12345678', '2026-04-23 03:29:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kategori_id` (`kategori_id`);

--
-- Indexes for table `buku_item`
--
ALTER TABLE `buku_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `buku_id` (`buku_id`);

--
-- Indexes for table `ebook`
--
ALTER TABLE `ebook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ebook_transactions`
--
ALTER TABLE `ebook_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `ebook_id` (`ebook_id`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifikasi`
--
ALTER TABLE `notifikasi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `buku_id` (`buku_id`);

--
-- Indexes for table `transaksi_ebook`
--
ALTER TABLE `transaksi_ebook`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `ebook_id` (`ebook_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `buku_item`
--
ALTER TABLE `buku_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `ebook`
--
ALTER TABLE `ebook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ebook_transactions`
--
ALTER TABLE `ebook_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `notifikasi`
--
ALTER TABLE `notifikasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `transaksi_ebook`
--
ALTER TABLE `transaksi_ebook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buku`
--
ALTER TABLE `buku`
  ADD CONSTRAINT `buku_ibfk_1` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `buku_item`
--
ALTER TABLE `buku_item`
  ADD CONSTRAINT `buku_item_ibfk_1` FOREIGN KEY (`buku_id`) REFERENCES `buku` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ebook_transactions`
--
ALTER TABLE `ebook_transactions`
  ADD CONSTRAINT `ebook_transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ebook_transactions_ibfk_2` FOREIGN KEY (`ebook_id`) REFERENCES `ebook` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifikasi`
--
ALTER TABLE `notifikasi`
  ADD CONSTRAINT `notifikasi_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `peminjaman_ibfk_2` FOREIGN KEY (`buku_id`) REFERENCES `buku` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transaksi_ebook`
--
ALTER TABLE `transaksi_ebook`
  ADD CONSTRAINT `transaksi_ebook_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transaksi_ebook_ibfk_2` FOREIGN KEY (`ebook_id`) REFERENCES `ebook` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
