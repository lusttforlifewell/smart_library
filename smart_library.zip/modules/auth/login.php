<?php
session_start();
require_once __DIR__ . '/../../config/database.php';

// If DB connection failed, set error to display and skip login processing
if (isset($dbConnectionError) && $dbConnectionError) {
    $error = 'Koneksi database gagal: ' . htmlspecialchars($dbConnectionError);
}

if (isset($_POST['login']) && isset($koneksi) && $koneksi) {
    $email = mysqli_real_escape_string($koneksi, $_POST['email']);
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE email=?";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        
        // Check password (support plain text & hashed)
        if (password_verify($password, $user['password']) || $password === $user['password']) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['nama'] = $user['nama'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['avatar'] = $user['avatar'];
            
            header("Location: ../dashboard/");
            exit();
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Email tidak terdaftar!";
    }
} else {
    // If DB missing and user attempted no action, ensure $error is set for display
    if (!isset($error) && (!isset($koneksi) || !$koneksi) && isset($dbConnectionError)) {
        $error = 'Koneksi database gagal: ' . htmlspecialchars($dbConnectionError);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Login - SmartLibrary</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-600 to-blue-800 h-screen flex items-center justify-center">
    <div class="bg-white p-8 rounded-xl shadow-2xl w-96">
        <h2 class="text-2xl font-bold text-center mb-2 text-slate-800">SmartLibrary</h2>
        <p class="text-center text-slate-500 mb-6 text-sm">SMK PGRI 1 Surabaya</p>
        
        <?php if(isset($error)) echo "<div class='bg-red-100 text-red-700 p-3 rounded mb-4 text-sm'>$error</div>"; ?>
        <?php if(isset($_SESSION['error'])) { echo "<div class='bg-red-100 text-red-700 p-3 rounded mb-4 text-sm'>".$_SESSION['error']."</div>"; unset($_SESSION['error']); } ?>
        
        <form method="POST">
            <label class="block text-sm font-medium mb-1">Email</label>
            <input type="email" name="email" class="w-full p-2 border rounded mb-3 focus:ring-2 focus:ring-blue-500 outline-none" required>
            
            <label class="block text-sm font-medium mb-1">Password</label>
            <input type="password" name="password" class="w-full p-2 border rounded mb-4 focus:ring-2 focus:ring-blue-500 outline-none" required>
            
            <button type="submit" name="login" class="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700 font-medium transition mb-3">Masuk</button>
        </form>

        <p class="text-center text-sm text-slate-500 mt-3">
            Belum punya akun? <a href="register.php" class="text-blue-600 font-semibold hover:underline">Daftar di sini</a>
        </p>
        
        <div class="mt-6 text-xs text-center text-slate-400 bg-slate-50 p-2 rounded">
            <p><strong>Super Admin:</strong> superadmin@smkpgri1.sch.id / 123456</p>
            <p><strong>Admin:</strong> admin@smkpgri1.sch.id / admin123</p>
            <p><strong>Siswa:</strong> siswa@smkpgri1.sch.id / siswa123</p>
        </div>
    </div>
</body>
</html>