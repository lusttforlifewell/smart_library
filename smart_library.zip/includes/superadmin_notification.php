<li class="nav-item dropdown">

    <a class="nav-link" 
       data-bs-toggle="dropdown"
       href="#">

        <i class="fas fa-bell"></i>

        <span 
            class="badge bg-danger navbar-badge"
            id="superadmin-count"
        >
            0
        </span>

    </a>

    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end">

        <span class="dropdown-header">
            Notifikasi
        </span>

        <div id="superadmin-area">

            <div class="dropdown-item">
                Tidak ada notifikasi
            </div>

        </div>

    </div>

</li>