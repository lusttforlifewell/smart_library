<?php

require_once __DIR__ . '/env.php';

# Read database config from environment with sensible defaults
$host = getenv('DB_HOST') ?: 'localhost';
$user = getenv('DB_USER') ?: 'root';
$pass = getenv('DB_PASS') ?: 'root';
$db   = getenv('DB_NAME') ?: 'pointgar_smart_library_db';
$projectRoot = str_replace('\\', '/', realpath(__DIR__ . '/../'));
$docRoot = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'] ?? ''));
$basePath = '/';

if ($docRoot && strpos($projectRoot, $docRoot) === 0) {
    $basePath = substr($projectRoot, strlen($docRoot));
    $basePath = '/' . trim($basePath, '/');
    if ($basePath === '/') {
        $basePath = '/';
    }
}

if ($basePath !== '/' && substr($basePath, -1) !== '/') {
    $basePath .= '/';
}

if (!defined('BASE_URL')) {
    define('BASE_URL', $basePath);
}
$koneksi = null;
$dbConnectionError = null;
try {
    // suppress warnings and capture connection error to handle gracefully
    $koneksi = @mysqli_connect($host, $user, $pass, $db);
    if (!$koneksi) {
        $dbConnectionError = mysqli_connect_error();
    }
} catch (\Throwable $e) {
    $koneksi = null;
    $dbConnectionError = $e->getMessage();
}
?>