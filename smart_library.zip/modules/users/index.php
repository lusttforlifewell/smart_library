<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../includes/auth_check.php';
include '../../config/database.php';

if ($_SESSION['role'] !== 'super_admin') {
    header("Location: ../dashboard/index.php");
    exit;
}

include '../../includes/header.php';

$search = isset($_GET['search']) ? mysqli_real_escape_string($koneksi, $_GET['search']) : '';

$query = mysqli_query($koneksi, "
    SELECT * FROM users 
    WHERE nama LIKE '%$search%' 
    OR email LIKE '%$search%'
    ORDER BY id DESC
");

if (!$query) {
    die("Query Error: " . mysqli_error($koneksi));
}
?>

<!-- 🔥 TOAST (ADD & DELETE DIGABUNG) -->
<?php if(isset($_GET['status'])): ?>

    <?php if($_GET['status'] == 'added'): ?>
        <div id="toast" class="fixed top-5 left-1/2 transform -translate-x-1/2 bg-white shadow-lg rounded-xl px-6 py-4 border-l-4 border-blue-500 z-50">
            <div class="flex items-center gap-3">
                <div class="bg-blue-500 text-white w-6 h-6 flex items-center justify-center rounded-full">✔</div>
                <div>
                    <p class="font-semibold">Berhasil</p>
                    <p class="text-sm text-gray-500">User berhasil ditambahkan</p>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if($_GET['status'] == 'deleted'): ?>
        <div id="toast" class="fixed top-5 left-1/2 transform -translate-x-1/2 bg-white shadow-lg rounded-xl px-6 py-4 border-l-4 border-green-500 z-50">
            <div class="flex items-center gap-3">
                <div class="bg-green-500 text-white w-6 h-6 flex items-center justify-center rounded-full">✔</div>
                <div>
                    <p class="font-semibold">Berhasil</p>
                    <p class="text-sm text-gray-500">User berhasil dihapus</p>
                </div>
            </div>
        </div>
    <?php endif; ?>

<?php endif; ?>

<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold text-slate-800">Kelola User</h1>

    <a href="add.php" class="bg-blue-600 text-white px-5 py-2 rounded-xl">
        + Tambah User
    </a>
</div>

<form method="GET" class="mb-4">
    <input type="text" name="search"
        value="<?= htmlspecialchars($search) ?>"
        placeholder="Cari nama / email..."
        class="w-full bg-gray-100 px-4 py-3 rounded-xl">
</form>

<div class="bg-white rounded-xl shadow overflow-hidden">
<table class="w-full">
<tr class="bg-gray-100">
    <th class="p-4">Nama</th>
    <th class="p-4">Email</th>
    <th class="p-4">Role</th>
    <th class="p-4 text-center">Aksi</th>
</tr>

<?php while($u = mysqli_fetch_assoc($query)): ?>
<tr class="border-t hover:bg-gray-50">
    <td class="p-4"><?= $u['nama'] ?></td>
    <td class="p-4"><?= $u['email'] ?></td>

    <td class="p-4">
        <span class="px-3 py-1 rounded-full text-sm
        <?= $u['role']=='super_admin' ? 'bg-purple-100 text-purple-600' : '' ?>
        <?= $u['role']=='admin' ? 'bg-blue-100 text-blue-600' : '' ?>
        <?= $u['role']=='siswa' ? 'bg-green-100 text-green-600' : '' ?>">
        <?= $u['role'] ?>
        </span>
    </td>

    <td class="p-4 text-center">
        <a href="edit.php?id=<?= $u['id'] ?>" class="text-blue-600">Edit</a>

        <?php if($u['role'] !== 'super_admin'): ?>
            |
            <a href="#" onclick="openModal(<?= $u['id'] ?>)" class="text-red-600">Delete</a>
        <?php endif; ?>
    </td>
</tr>
<?php endwhile; ?>
</table>
</div>

<!-- 🔥 MODAL -->
<div id="deleteModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white p-6 rounded-xl shadow-lg w-80 text-center">
        <h2 class="text-lg font-bold mb-3">Konfirmasi</h2>
        <p class="mb-4 text-gray-600">Yakin ingin menghapus user?</p>

        <div class="flex justify-center gap-3">
            <button onclick="closeModal()" class="px-4 py-2 bg-gray-300 rounded">Batal</button>

            <a id="confirmDelete" class="px-4 py-2 bg-red-600 text-white rounded">
                Hapus
            </a>
        </div>
    </div>
</div>

<!-- 🔥 SCRIPT -->
<script>
function openModal(id) {
    document.getElementById('deleteModal').classList.remove('hidden');
    document.getElementById('deleteModal').classList.add('flex');

    document.getElementById('confirmDelete').href = "delete.php?id=" + id;
}

function closeModal() {
    document.getElementById('deleteModal').classList.add('hidden');
}

// auto hilang toast
setTimeout(() => {
    let toast = document.getElementById('toast');
    if (toast) toast.remove();
}, 3000);
</script>

<?php include '../../includes/footer.php'; ?>