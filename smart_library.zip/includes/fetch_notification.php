<?php

require_once __DIR__ . '/../config/database.php';

if(session_status() == PHP_SESSION_NONE){
    session_start();
}

if(!isset($_SESSION['user_id'])){
    exit;
}

$user_id = $_SESSION['user_id'];
$role    = strtolower(trim($_SESSION['role']));

// ==========================
// QUERY NOTIF
// ==========================
$notifQuery = mysqli_query($koneksi, "
    SELECT *
    FROM notifikasi
    WHERE user_id='$user_id'
    ORDER BY created_at DESC
    LIMIT 15
");

?>

<?php if($notifQuery && mysqli_num_rows($notifQuery) > 0): ?>

    <?php while($notif = mysqli_fetch_assoc($notifQuery)): ?>

        <div class="p-4 border-b hover:bg-slate-50 transition">

            <!-- TYPE -->
            <div class="
                text-sm font-bold mb-1

                <?php

                if($notif['tipe'] == 'success') {

                    echo 'text-green-600';

                }
                elseif($notif['tipe'] == 'warning') {

                    echo 'text-yellow-600';

                }
                elseif($notif['tipe'] == 'info') {

                    echo 'text-blue-600';

                }
                else {

                    echo 'text-red-600';

                }

                ?>
            ">

                <?php echo ucfirst($notif['tipe']); ?>

            </div>

            <!-- MESSAGE -->
            <div class="text-sm text-slate-700 leading-relaxed">

                <?php echo htmlspecialchars($notif['pesan']); ?>

            </div>

            <!-- DATE -->
            <div class="text-xs text-slate-400 mt-2">

                <?php echo date('d M Y H:i', strtotime($notif['created_at'])); ?>

            </div>

        </div>

    <?php endwhile; ?>

<?php else: ?>

    <div class="p-6 text-center text-slate-400">

        Tidak ada notifikasi

    </div>

<?php endif; ?>